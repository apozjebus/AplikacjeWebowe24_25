__copyright__ = "Zespół Szkół Komunikacji"
__author__ = "Mateusz Gliszczynski 4d"

from .Student import Student
from .Subject import Subject

class Grades:
    def __init__(self, student: Student, subject: Subject):
        self.grades = []
        self.student = student
        self.subject = subject

    def add_grade(self, grade: int) -> None:
        if 1 <= grade <= 6:
            self.grades.append(grade)
        else:
            raise ValueError("Grade must be between 1 and 6")

    def get_grades(self) -> list[int]:
        return self.grades

    def get_average(self) -> float:
        if len(self.grades) == 0:
            return 0.0
        return sum(self.grades) / len(self.grades)