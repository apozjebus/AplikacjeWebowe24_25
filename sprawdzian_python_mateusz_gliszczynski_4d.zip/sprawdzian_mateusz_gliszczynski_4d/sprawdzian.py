__copyright__ = "Zespół Szkół Komunikacji"
__author__ = "Mateusz Gliszczynski 4d"

from models.Teacher import Teacher
from models.Student import Student
from models.Subject import Subject
from models.Grades import Grades
import datetime as dt
import json

if __name__ == "__main__":
    teachers: list[Teacher] = []
    students: list[Student] = []
    subjects: list[Subject] = []
    grades: list[Grades] = []

    with open('teachers.txt', 'r') as file:
        for line in file:
            _id, name, surname = line.strip().split(' ')
            _id = int(_id)
            teachers.append(Teacher(_id, name, surname))

    with open('students.txt', 'r') as file:
        for line in file:
            _id, first_name, last_name, birth_date = line.strip().split(' ')
            _id = int(_id)
            birth_date = dt.datetime.strptime(birth_date, '%Y-%m-%d').date()
            students.append(Student(_id, first_name, last_name, birth_date))

    with open('subjects.txt', 'r') as file:
        for line in file:
            _id, name, teacher_id = line.strip().split(' ')
            _id = int(_id)
            teacher_id = int(teacher_id)
            teacher = next((t for t in teachers if t._id == teacher_id), None)
            subjects.append(Subject(_id, name, teacher))

    with open('grades.txt', 'r') as file:
        for line in file:
            s_id, subj_id, raw_grades = line.strip().split(' ')
            s_id = int(s_id)
            subj_id = int(subj_id)
            grade_values = list(map(int, raw_grades.split(',')))
            student = next((s for s in students if s._id == s_id), None)
            subject = next((s for s in subjects if s._id == subj_id), None)
            if student and subject:
                grades_obj = Grades(student, subject)
                for g in grade_values:
                    grades_obj.add_grade(g)
                grades.append(grades_obj)

    print("Oceny i średnie poszczególnych uczniów")
    for student in students:
        print(f"{student.first_name} {student.last_name} ({student.age}):")
        student_grades = [g for g in grades if g.student == student]
        for grade in student_grades:
            average = grade.get_average()
            final_grade = round(average)
            grade_str = ", ".join(str(g) for g in grade.get_grades())
            print(f"\t{grade.subject.name}:")
            print(f"\t\tOceny: {grade_str}")
            print(f"\t\tŚrednia: {average:.2f}")
            print(f"\t\tOcena końcowa: {final_grade}")
        print()

    students_data = []

    for student in students:
        student_key = f"{student.first_name} {student.last_name} ({student.age})"
        student_grades = [g for g in grades if g.student == student]

        subjects_dict = {}
        for grade in student_grades:
            grade_str = ", ".join(str(g) for g in grade.get_grades())
            average = grade.get_average()
            final_grade = round(average)

            subjects_dict[grade.subject.name] = {
                "Oceny": grade_str,
                "Srednia": round(average, 2),
                "Ocena roczna": final_grade
            }

        students_data.append({student_key: subjects_dict})

    with open('students.json', 'w', encoding='utf-8') as json_file:
        json.dump(students_data, json_file, indent=4, ensure_ascii=False)

    print('=' * 50)
    print()

    for subject in subjects:
        print(f"{subject.name}:")
        print(f"Nauczyciel: {subject.teacher}")

        subject_grades = [g for g in grades if g.subject == subject]
        all_grades = []
        for grade_obj in subject_grades:
            all_grades.extend(grade_obj.get_grades())

        grades_str = ", ".join(str(g) for g in all_grades)

        average = sum(all_grades) / len(all_grades) if all_grades else 0

        print(f"Oceny: {grades_str}")
        print(f"Średnia: {average:.2f}")
        print()

    subjects_data = []

    for subject in subjects:
        subject_grades = [g for g in grades if g.subject == subject]
        all_grades = []
        for grade_obj in subject_grades:
            all_grades.extend(grade_obj.get_grades())

        average = sum(all_grades) / len(all_grades) if all_grades else 0

        subject_dict = {
            subject.name: {
                "Nauczyciel": str(subject.teacher),
                "Oceny": all_grades,
                "Srednia": round(average, 2)
            }
        }

        subjects_data.append(subject_dict)

    with open('subjects.json', 'w', encoding='utf-8') as json_file:
        json.dump(subjects_data, json_file, indent=4, ensure_ascii=False)